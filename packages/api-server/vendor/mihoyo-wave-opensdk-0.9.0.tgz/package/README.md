# @mihoyo/wave-opensdk

HoYowave 开放平台 SDK

## Feature

- 💪🏻 类型安全 - **100%**的`ts`类型支持
- 🧪 运行安全 - **100%**的单测行覆盖
- 🤝🏻 模块同构 - 同时支持`ESM`和`CJS`模块
- 🌍 环境同构 - 同时支持`Node.js`环境和浏览器环境
- 🍃 摇树友好 - 无副作用, 支持细粒度 treeshake
- 🚀 高效快捷 - 内置大量 api 快捷方式与自动判断

## Install

该包为内网私有包， 请先设置 npm 源为内网私有源 `https://plat-registry-npm.mihoyo.com` 后进行安装

```bash
npm install @mihoyo/wave-opensdk
```

## USAGE

### 创建应用实例

需要先在[HoYowave 开放平台](https://op.hoyowave.com/#/application)手动创建一个应用, 然后使用该应用的信息按照如下演示初始化一个应用实例.

- `appId` 与 `appSecret` 在 [开放平台 - 应用详情 - 基础信息与应用凭证] tab 中获取
- `aesKey` 与 `token` 在 [开放平台 - 应用详情 - 事件订阅] tab 中获取

```ts
import { createApp, createAppMsg } from '@mihoyo/wave-opensdk'

const app = createApp({
  appId: '<YOUR_APP_ID>',
  appSecret: '<YOUR_APP_SECRET>',
  aesKey: '<YOUR_APP_AES_KEY>',
  token: '<YOUR_APP_TOKEN>',
})
// app.msg.send(...)

// 或者你只使用到应用的一部分能力（例如只需要发消息）, 也可以只初始化对应能力的实例
// 这种方式可以进一步更细致的 treeshake, 有利于产生更小的包体积
const appMsg = createAppMsg({
  appId: '<YOUR_APP_ID>',
  appSecret: '<YOUR_APP_SECRET>',
  aesKey: '<YOUR_APP_AES_KEY>',
  token: '<YOUR_APP_TOKEN>',
})
// appMsg.send(...)

// 其余能力按照模块划分也可同样只初始化对应能力的实例
// 可参考: [./test/fixtures/config.ts](https://platgit.mihoyo.com/open-wave/wave-js-opensdk/-/tree/master/test/fixtures/config.ts)
```

后续示例中将直接使用`app`作为已创建好的应用实例演示调用

### 创建机器人实例

需要先在 HoYowave 群内手动创建一个[机器人](https://km.mihoyo.com/articleBase/5173/377212?sT=%E7%BE%A4%E6%9C%BA%E5%99%A8%E4%BA%BA#NjkwxhcXh26czMs8pcO4Lx), 然后使用该机器人的信息按照如下演示初始化一个机器人实例.

群内创建的普通**机器人**仅支持发送消息到该群内, 不支持任何其他功能, 如需其他功能, 请使用**应用**.

```ts
import { createBot } from '@mihoyo/wave-opensdk'

const bot = createBot({
  webhook: '<YOUR_BOT_WEBHOOK>',
  // `token` 是可选项, 仅在你的机器人使用了签名校验方式时需要
  // token: '<YOUR_BOT_TOKEN>',
})
```

后续示例中将直接使用`bot`作为已创建好的机器人实例演示调用

### 应用消息

你的应用需要先开通消息对应的权限: [消息](https://km.mihoyo.com/articleBase/5173/356861)

- 发送消息
- 回复消息
- 撤回消息
- 查询消息内容
- 获取消息中表情回复类型
- 获取消息中表情回复人员列表
- 通知消息已读
- 更新卡片消息 (主动更新 | 延迟更新)

- 发送批量消息
- 查询批量消息进度
- 撤回批量消息

```ts
import { msgMarkdown } from '@mihoyo/wave-opensdk'

// 或者 const appMsg = createAppMsg({/**... */})

// 通过应用发送私聊消息给 `san.zhang`
const result = await app.msg.send('san.zhang', msgMarkdown('# Hi'))
// result => ResultSendMsg<MsgCard>
```

更多应用消息相关可查看单测: [./test/app.msg.test.ts](https://platgit.mihoyo.com/open-wave/wave-js-opensdk/-/tree/master/test/app/app.msg.test.ts)

或者在安装包以后通过`app.msg.`的`ts`代码提示查看所有可用的消息相关 api

### 机器人消息

- 发送消息

```ts
import { msgMarkdown } from '@mihoyo/wave-opensdk'

// 通过机器人发送消息到所在的群
const result = await bot.send(msgMarkdown('# Hi'))
// result => ResultSendMsg<MsgCard>
```

更多机器人消息案例可查看单测: [./test/bot.test.ts](https://platgit.mihoyo.com/open-wave/wave-js-opensdk/-/tree/master/test/app/bot.test.ts)

或者在安装包以后通过`bot.`的`ts`代码提示查看所有可用的机器人相关 api

### 群组

你的应用需要先开通群组对应的权限: [群组](https://km.mihoyo.com/articleBase/5173/356862)

- 创建群
- 获取群信息
- 更新群信息
- 获取群成员列表
- 获取应用所在群列表
- 将用户或者应用拉入群聊
- 将用户或者应用移出群聊
- 更新群公告
- 添加群会话标签页
- 转移群主
- 解散群
- 设置群管理员
- 更新群配置

```ts
// 或者 const appChat = createAppChat({/**... */})

// 创建群聊
const result = await app.chat.create({
  name: '[SDK] test',
  owner_id: 'san.zhang',
  member_id_list: ['san.zhang', 'si.li'],
})
// result => ResultCreateChat
```

更多群组相关可查看单测: [./test/app.chat.test.ts](https://platgit.mihoyo.com/open-wave/wave-js-opensdk/-/tree/master/test/app/app.chat.test.ts)

或者在安装包以后通过`app.chat.`的`ts`代码提示查看所有可用的群组相关 api

### 通讯录

你的应用需要先开通通讯录对应的权限: [通讯录](https://km.mihoyo.com/articleBase/5173/356863)

- 批量获取用户信息
- 用户 union_id 和 user_id (域账号) 互转

```ts
// 或者 const appContact = createAppContact({/**... */})

// 批量获取用户信息
const result = await app.contact.getUsers(['san.zhang', 'si.li'])
// result => ResultGetUsers
```

更多通讯录相关可查看单测: [./test/app.contact.test.ts](https://platgit.mihoyo.com/open-wave/wave-js-opensdk/-/tree/master/test/app/app.contact.test.ts)

或者在安装包以后通过`app.contact.`的`ts`代码提示查看所有可用的通讯录相关 api

### 文件

你的应用需要先开通文件对应的权限: [文件](https://km.mihoyo.com/articleBase/5173/357055)

- 上传图片
- 上传文件
- 获取文件公网访问链接

```ts
// 或者 const appFile = createAppFile({/**... */})

// 上传图片
const result = await app.file.uploadImage(file)
// result => ResultUploadImage
```

更多文件相关可查看单测: [./test/app.file.test.ts](https://platgit.mihoyo.com/open-wave/wave-js-opensdk/-/tree/master/test/app/app.file.test.ts)

或者在安装包以后通过`app.file.`的`ts`代码提示查看所有可用的文件相关 api

### 应用设置

- 设置应用可见性
- 查询应用可见性
- 查询通知助手通知类型

```ts
// 或者 const appConfig = createAppConfig({/**... */})

// 设置应用可见性
const result = await app.config.setVisibility({
  uids: ['san.zhang', 'si.li'],
  op_type: 'overwrite',
})
```

更多应用设置相关可查看单测: [./test/app.config.test.ts](https://platgit.mihoyo.com/open-wave/wave-js-opensdk/-/tree/master/test/app/app.config.test.ts)

或者在安装包以后通过`app.config.`的`ts`代码提示查看所有可用的应用设置相关 api

### 公共

- 获取应用事件出口 IP

```ts
// 或者 const appPublic = createAppPublic({/**... */})

// 获取应用事件出口 IP
const result = await app.public.listIp()
```

更多应用设置相关可查看单测: [./test/app.public.test.ts](https://platgit.mihoyo.com/open-wave/wave-js-opensdk/-/tree/master/test/app/app.public.test.ts)

或者在安装包以后通过`app.public.`的`ts`代码提示查看所有可用的应用公共相关 api

### 事件订阅

你的应用需要先开通事件对应的权限: [事件列表](https://km.mihoyo.com/articleBase/5173/356864)

- 回调地址校验(第一步, 必须先配置该事件通过校验后才能接收其余事件)
- 收到单聊消息或者群内@消息
- 收到群内任何消息(权限要求高, 一般不需要)
- 收到用户和卡片消息交互事件
- 用户进入应用私聊会话
- 用户或应用加入群聊
- 用户或应用退出群聊
- 群聊解散

```ts
// 或者 const appEvent = createAppEvent({/**... */})
app.event
  // [回调地址校验]事件会默认处理, 通常来说你不需要手动注册`onVerify`事件函数
  // .onVerify(event => event.event.challenge)
  // 注册应用[被私聊或者群内被@]时的事件函数
  .onMsgSendDirect(event => event.schema)
  // 注册应用[收到群内所有消息]的事件函数
  .onMsgSendGroup(event => event.header.app_id)
  // 注册应用[收到卡片消息交互回调]的事件函数
  .onMsgCardReaction(event => event.header.event_type)
  /** ... */
  // 注册应用[任何未被注册事件]的事件函数
  .onUnhandled(event => `Unknown event: ${JSON.stringify(event.event)}`)
  // 注册应用[任何 SDK 当前还未支持]的事件函数
  .on('any event', event => `Any event: ${JSON.stringify(event.event)}`)

// 处理任何来自 hoyowave 平台的订阅数据
// 这会自动使用上面已注册的事件函数来按照你的需求处理数据
// `requst body` 代表网络请求的 body 数据(JSON 格式)
// `result` 代表所注册的对应事件函数执行后的返回值
const result = app.handle(/** requst body */)
```

本地开发可以参见[事件办公网推送](https://km.mihoyo.com/articleBase/5173/552962), 可使用本地服务接收事件订阅信息.

更多应用事件相关可查看单测: [./test/app.event.test.ts](https://platgit.mihoyo.com/open-wave/wave-js-opensdk/-/tree/master/test/app/app.event.test.ts)

或者在安装包以后通过`app.event.`的`ts`代码提示查看所有可用的应用事件相关 api

## Q & A

如果有疑问可以搜索 HoYowave 公开群: [Wave开放平台答疑群], 在群内可以答疑

(🤔 或者更具体关于该 nodejs sdk 本身的问题可以私聊维护者 @da.ma :)
